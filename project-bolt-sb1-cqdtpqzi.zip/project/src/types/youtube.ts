export interface VideoData {
  id: string;
  title: string;
  publishedAt: string;
  thumbnail: string;
  url: string;
  views: number;
  likes: number;
  comments: number;
  shares: number;
  type: VideoType;
}

export type VideoType = 'Video' | 'Short' | 'Live' | 'Playlist' | 'Post' | 'Podcast' | 'Promotion';

export interface SocialLink {
  platform: 'twitter' | 'instagram' | 'facebook' | 'tiktok' | 'website';
  url: string;
}

export interface ChannelStats {
  id: string;
  title: string;
  description: string;
  customUrl: string;
  thumbnails: {
    default: string;
    medium: string;
    high: string;
    banner?: string;
  };
  socialLinks: SocialLink[];
  subscriberCount: number;
  videoCount: number;
  viewCount: number;
}