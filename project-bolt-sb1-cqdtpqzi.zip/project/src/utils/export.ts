import * as XLSX from 'xlsx';
import { VideoData } from '../types/youtube';

export function exportToExcel(data: VideoData[], filename: string = 'youtube-data.xlsx') {
  const worksheet = XLSX.utils.json_to_sheet(
    data.map(video => ({
      Title: video.title,
      'Published Date': new Date(video.publishedAt).toLocaleDateString(),
      Views: video.views,
      Type: video.type,
    }))
  );

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Videos');
  XLSX.writeFile(workbook, filename);
}