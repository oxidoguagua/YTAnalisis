export function parseYouTubeChannelUrl(url: string): string | null {
  // Clean up the URL
  const cleanUrl = url.trim().toLowerCase();

  // Handle various URL formats
  const patterns = [
    // Handle @username format
    /(?:https?:\/\/)?(?:www\.)?youtube\.com\/@([\w-]+)/,
    // Handle /channel/ format
    /(?:https?:\/\/)?(?:www\.)?youtube\.com\/channel\/([\w-]+)/,
    // Handle /c/ format
    /(?:https?:\/\/)?(?:www\.)?youtube\.com\/c\/([\w-]+)/,
    // Handle /user/ format
    /(?:https?:\/\/)?(?:www\.)?youtube\.com\/user\/([\w-]+)/,
    // Handle direct @username
    /^@([\w-]+)$/,
  ];

  for (const pattern of patterns) {
    const match = cleanUrl.match(pattern);
    if (match && match[1]) {
      return match[1];
    }
  }

  return null;
}