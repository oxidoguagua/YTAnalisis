import { VideoData, VideoType, ChannelStats, SocialLink } from '../types/youtube';
import { parseYouTubeChannelUrl } from './url-parser';
import { fetchFromYouTube } from './api-client';
import { validateConfig } from './config';

export async function getChannelData(channelUrl: string) {
  try {
    validateConfig();

    const channelIdentifier = parseYouTubeChannelUrl(channelUrl);
    if (!channelIdentifier) {
      throw new Error(
        'Invalid channel URL. Please enter a YouTube channel URL or handle (e.g., youtube.com/@handle, youtube.com/channel/ID, or just @handle)'
      );
    }

    const channelId = await getChannelId(channelIdentifier);
    const [channelStats, videos] = await Promise.all([
      fetchChannelStats(channelId),
      fetchChannelVideos(channelId),
    ]);

    return { stats: channelStats, videos };
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('An unexpected error occurred while fetching channel data');
  }
}

async function getChannelId(identifier: string): Promise<string> {
  // Try direct channel ID first
  if (identifier.length > 20) {
    try {
      const data = await fetchFromYouTube('channels', {
        part: 'id',
        id: identifier,
      });
      if (data.items?.length) {
        return identifier;
      }
    } catch (error) {
      console.error('Error checking channel ID:', error);
    }
  }

  // Search for channel
  const data = await fetchFromYouTube('search', {
    part: 'snippet',
    type: 'channel',
    q: identifier,
  });

  const channelId = data.items?.[0]?.id?.channelId;
  if (!channelId) {
    throw new Error('Channel not found');
  }

  return channelId;
}

async function fetchChannelStats(channelId: string): Promise<ChannelStats> {
  const data = await fetchFromYouTube('channels', {
    part: 'snippet,statistics,brandingSettings',
    id: channelId,
  });

  const channel = data.items?.[0];
  if (!channel) {
    throw new Error('Channel not found');
  }

  const socialLinks = extractSocialLinks(channel.snippet.description);

  return {
    id: channel.id,
    title: channel.snippet.title,
    description: channel.snippet.description,
    customUrl: channel.snippet.customUrl,
    thumbnails: {
      ...channel.snippet.thumbnails,
      banner: channel.brandingSettings?.image?.bannerExternalUrl,
    },
    socialLinks,
    subscriberCount: parseInt(channel.statistics.subscriberCount || '0'),
    videoCount: parseInt(channel.statistics.videoCount || '0'),
    viewCount: parseInt(channel.statistics.viewCount || '0'),
  };
}

async function fetchChannelVideos(channelId: string): Promise<VideoData[]> {
  const videos: VideoData[] = [];
  let pageToken: string | undefined;

  do {
    const searchData = await fetchFromYouTube('search', {
      channelId,
      part: 'snippet',
      maxResults: '50',
      order: 'date',
      type: 'video',
      ...(pageToken ? { pageToken } : {}),
    });

    if (!searchData.items?.length) break;

    const videoIds = searchData.items.map((item: any) => item.id.videoId);
    const statsData = await fetchFromYouTube('videos', {
      id: videoIds.join(','),
      part: 'statistics,snippet',
    });

    statsData.items?.forEach((video: any) => {
      if (video.id && video.snippet && video.statistics) {
        videos.push({
          id: video.id,
          title: video.snippet.title,
          publishedAt: video.snippet.publishedAt,
          thumbnail: `https://i.ytimg.com/vi/${video.id}/default.jpg`,
          url: `https://youtube.com/watch?v=${video.id}`,
          views: parseInt(video.statistics.viewCount || '0'),
          likes: parseInt(video.statistics.likeCount || '0'),
          comments: parseInt(video.statistics.commentCount || '0'),
          shares: parseInt(video.statistics.shareCount || '0'),
          type: determineVideoType(video.snippet),
        });
      }
    });

    pageToken = searchData.nextPageToken;
  } while (pageToken);

  return videos;
}

function determineVideoType(snippet: any): VideoType {
  const title = snippet.title.toLowerCase();
  const description = (snippet.description || '').toLowerCase();

  if (snippet.liveBroadcastContent === 'live') return 'Live';
  if (snippet.liveBroadcastContent === 'upcoming') return 'Live';
  if (title.includes('#shorts') || description.includes('#shorts')) return 'Short';
  if (title.includes('podcast') || description.includes('podcast')) return 'Podcast';
  if (title.includes('playlist') || description.includes('playlist')) return 'Playlist';
  if (title.includes('promoción') || title.includes('promotion')) return 'Promotion';
  if (snippet.categoryId === '17') return 'Post';
  
  return 'Video';
}

function extractSocialLinks(description: string): SocialLink[] {
  const socialLinks: SocialLink[] = [];
  const patterns = [
    { platform: 'twitter', regex: /twitter\.com\/([^\s]+)/i },
    { platform: 'instagram', regex: /instagram\.com\/([^\s]+)/i },
    { platform: 'facebook', regex: /facebook\.com\/([^\s]+)/i },
    { platform: 'tiktok', regex: /tiktok\.com\/@([^\s]+)/i },
    { platform: 'website', regex: /(https?:\/\/[^\s]+\.[^\s]+)/i },
  ] as const;

  patterns.forEach(({ platform, regex }) => {
    const match = description.match(regex);
    if (match) {
      socialLinks.push({
        platform,
        url: match[0].startsWith('http') ? match[0] : `https://${match[0]}`,
      });
    }
  });

  return socialLinks;
}