import { config } from './config';

interface ApiResponse<T> {
  items?: T[];
  nextPageToken?: string;
  error?: {
    message: string;
    code: number;
  };
}

export async function fetchFromYouTube<T>(
  endpoint: string,
  params: Record<string, string>
): Promise<ApiResponse<T>> {
  const url = new URL(`${config.youtube.baseUrl}/${endpoint}`);
  url.searchParams.append('key', config.youtube.apiKey);
  
  for (const [key, value] of Object.entries(params)) {
    url.searchParams.append(key, value);
  }

  const response = await fetch(url.toString());
  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.error?.message || 'Failed to fetch data from YouTube API');
  }

  return data;
}