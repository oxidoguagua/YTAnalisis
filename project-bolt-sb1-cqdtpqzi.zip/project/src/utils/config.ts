export const config = {
  youtube: {
    baseUrl: 'https://www.googleapis.com/youtube/v3',
    apiKey: import.meta.env.VITE_YOUTUBE_API_KEY,
  },
} as const;

export function validateConfig() {
  if (!config.youtube.apiKey) {
    throw new Error(
      'YouTube API key is missing. Please add VITE_YOUTUBE_API_KEY to your .env file.'
    );
  }
}