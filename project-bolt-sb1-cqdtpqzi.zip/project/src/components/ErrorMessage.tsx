import React from 'react';
import { AlertCircle } from 'lucide-react';

interface ErrorMessageProps {
  message: string;
  onClose: () => void;
}

export function ErrorMessage({ message, onClose }: ErrorMessageProps) {
  return (
    <div className="fixed top-4 right-4 bg-red-50 text-red-700 px-4 py-3 rounded-lg shadow-lg flex items-center gap-2">
      <AlertCircle className="w-5 h-5" />
      <p>{message}</p>
      <button
        onClick={onClose}
        className="ml-4 text-red-500 hover:text-red-700"
      >
        ×
      </button>
    </div>
  );
}