import React from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import { VideoData, VideoType } from '../types/youtube';
import { format, parseISO } from 'date-fns';
import { VideoTooltip } from './VideoTooltip';

interface StatsChartProps {
  data: VideoData[];
  selectedTypes: VideoType[];
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload || !payload.length) return null;

  return (
    <div className="grid grid-cols-1 gap-4">
      {payload.map((entry: any, index: number) => {
        const video = entry.payload.videoData[entry.dataKey];
        if (!video) return null;

        return (
          <div key={index}>
            <VideoTooltip video={video} />
          </div>
        );
      })}
    </div>
  );
};

export function StatsChart({ data, selectedTypes }: StatsChartProps) {
  const chartData = data
    .sort((a, b) => new Date(a.publishedAt).getTime() - new Date(b.publishedAt).getTime())
    .map((video) => {
      const dataPoint: any = {
        date: format(parseISO(video.publishedAt), 'MM/dd/yyyy'),
        videoData: {},
      };

      selectedTypes.forEach((type) => {
        if (video.type === type) {
          dataPoint[type] = video.views;
          dataPoint.videoData[type] = video;
        } else {
          dataPoint[type] = 0;
          dataPoint.videoData[type] = null;
        }
      });

      return dataPoint;
    });

  const colors = {
    Video: '#2563eb',
    Short: '#dc2626',
    Live: '#16a34a',
    Playlist: '#9333ea',
    Post: '#ea580c',
    Podcast: '#0891b2',
    Promotion: '#db2777',
  };

  return (
    <div className="h-[400px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={chartData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="date" />
          <YAxis />
          <Tooltip content={<CustomTooltip />} />
          <Legend />
          {selectedTypes.map((type) => (
            <Line
              key={type}
              type="monotone"
              dataKey={type}
              stroke={colors[type]}
              strokeWidth={2}
              dot={{ r: 4 }}
              activeDot={{ r: 6 }}
            />
          ))}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}