import React from 'react';
import { ChannelStats } from '../types/youtube';
import { Users, Video, Eye } from 'lucide-react';

interface ChannelInfoProps {
  stats: ChannelStats;
}

export function ChannelInfo({ stats }: ChannelInfoProps) {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
      <div className="flex items-center gap-6 mb-6">
        <img
          src={stats.thumbnails.medium}
          alt={stats.title}
          className="w-24 h-24 rounded-full"
        />
        <div>
          <h1 className="text-2xl font-bold mb-2">{stats.title}</h1>
          <a
            href={`https://youtube.com/${stats.customUrl}`}
            target="_blank"
            rel="noopener noreferrer"
            className="text-blue-600 hover:text-blue-800"
          >
            @{stats.customUrl}
          </a>
        </div>
      </div>

      <p className="text-gray-600 mb-6">{stats.description}</p>

      <div className="grid grid-cols-3 gap-6">
        <div className="bg-blue-50 rounded-lg p-4">
          <div className="flex items-center gap-2 text-blue-700 mb-2">
            <Users className="w-5 h-5" />
            <h3 className="font-semibold">Subscribers</h3>
          </div>
          <p className="text-2xl font-bold text-blue-900">
            {stats.subscriberCount.toLocaleString()}
          </p>
        </div>

        <div className="bg-green-50 rounded-lg p-4">
          <div className="flex items-center gap-2 text-green-700 mb-2">
            <Video className="w-5 h-5" />
            <h3 className="font-semibold">Videos</h3>
          </div>
          <p className="text-2xl font-bold text-green-900">
            {stats.videoCount.toLocaleString()}
          </p>
        </div>

        <div className="bg-purple-50 rounded-lg p-4">
          <div className="flex items-center gap-2 text-purple-700 mb-2">
            <Eye className="w-5 h-5" />
            <h3 className="font-semibold">Total Views</h3>
          </div>
          <p className="text-2xl font-bold text-purple-900">
            {stats.viewCount.toLocaleString()}
          </p>
        </div>
      </div>
    </div>
  );
}