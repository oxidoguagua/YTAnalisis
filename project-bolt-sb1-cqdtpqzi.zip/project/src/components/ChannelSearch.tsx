import React, { useState } from 'react';
import { Search } from 'lucide-react';

interface ChannelSearchProps {
  onSearch: (channelUrl: string) => void;
  isLoading?: boolean;
}

export function ChannelSearch({ onSearch, isLoading = false }: ChannelSearchProps) {
  const [channelUrl, setChannelUrl] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (channelUrl.trim()) {
      onSearch(channelUrl);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="w-full max-w-2xl mx-auto mb-8">
      <div className="flex gap-2">
        <div className="relative flex-1">
          <input
            type="text"
            placeholder="Enter YouTube channel URL"
            value={channelUrl}
            onChange={(e) => setChannelUrl(e.target.value)}
            className="w-full px-4 py-2 pl-10 border rounded-md focus:outline-none focus:ring-2 focus:ring-red-500"
          />
          <Search className="absolute left-3 top-2.5 w-5 h-5 text-gray-400" />
        </div>
        <button
          type="submit"
          disabled={isLoading}
          className="px-6 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors disabled:opacity-50"
        >
          {isLoading ? 'Loading...' : 'Analyze'}
        </button>
      </div>
    </form>
  );
}