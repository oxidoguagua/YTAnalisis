import React from 'react';
import {
  createColumnHelper,
  flexRender,
  getCoreRowModel,
  useReactTable,
  getSortedRowModel,
  getFilteredRowModel,
} from '@tanstack/react-table';
import { VideoData } from '../types/youtube';
import { format } from 'date-fns';
import { ExternalLink, ThumbsUp, MessageSquare, Share2 } from 'lucide-react';

const columnHelper = createColumnHelper<VideoData>();

const columns = [
  columnHelper.accessor('thumbnail', {
    header: 'Thumbnail',
    cell: (info) => (
      <img 
        src={info.getValue()} 
        alt="Video thumbnail" 
        className="w-24 h-auto rounded"
      />
    ),
  }),
  columnHelper.accessor('title', {
    header: 'Title',
    cell: (info) => (
      <div className="flex items-center gap-2">
        <span>{info.getValue()}</span>
        <a 
          href={info.row.original.url} 
          target="_blank" 
          rel="noopener noreferrer"
          className="text-blue-600 hover:text-blue-800"
        >
          <ExternalLink className="w-4 h-4" />
        </a>
      </div>
    ),
  }),
  columnHelper.accessor('publishedAt', {
    header: 'Published',
    cell: (info) => format(new Date(info.getValue()), 'PPP'),
  }),
  columnHelper.accessor('views', {
    header: 'Views',
    cell: (info) => info.getValue().toLocaleString(),
  }),
  columnHelper.accessor('likes', {
    header: 'Likes',
    cell: (info) => (
      <div className="flex items-center gap-1">
        <ThumbsUp className="w-4 h-4" />
        {info.getValue().toLocaleString()}
      </div>
    ),
  }),
  columnHelper.accessor('comments', {
    header: 'Comments',
    cell: (info) => (
      <div className="flex items-center gap-1">
        <MessageSquare className="w-4 h-4" />
        {info.getValue().toLocaleString()}
      </div>
    ),
  }),
  columnHelper.accessor('shares', {
    header: 'Shares',
    cell: (info) => (
      <div className="flex items-center gap-1">
        <Share2 className="w-4 h-4" />
        {info.getValue().toLocaleString()}
      </div>
    ),
  }),
  columnHelper.accessor('type', {
    header: 'Type',
    cell: (info) => info.getValue(),
  }),
];

interface VideoTableProps {
  data: VideoData[];
}

export function VideoTable({ data }: VideoTableProps) {
  const table = useReactTable({
    data,
    columns,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
  });

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          {table.getHeaderGroups().map((headerGroup) => (
            <tr key={headerGroup.id}>
              {headerGroup.headers.map((header) => (
                <th
                  key={header.id}
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100"
                  onClick={header.column.getToggleSortingHandler()}
                >
                  {flexRender(
                    header.column.columnDef.header,
                    header.getContext()
                  )}
                  <span className="ml-2">
                    {{
                      asc: '↑',
                      desc: '↓',
                    }[header.column.getIsSorted() as string] ?? ''}
                  </span>
                </th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {table.getRowModel().rows.map((row) => (
            <tr key={row.id} className="hover:bg-gray-50">
              {row.getVisibleCells().map((cell) => (
                <td
                  key={cell.id}
                  className="px-6 py-4 whitespace-nowrap text-sm text-gray-500"
                >
                  {flexRender(cell.column.columnDef.cell, cell.getContext())}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}