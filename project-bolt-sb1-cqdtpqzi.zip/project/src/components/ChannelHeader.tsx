import React from 'react';
import { ChannelStats } from '../types/youtube';
import { Twitter, Instagram, Facebook, Globe, BrandTiktok } from 'lucide-react';

const socialIcons = {
  twitter: Twitter,
  instagram: Instagram,
  facebook: Facebook,
  tiktok: BrandTiktok,
  website: Globe,
};

interface ChannelHeaderProps {
  stats: ChannelStats;
}

export function ChannelHeader({ stats }: ChannelHeaderProps) {
  return (
    <div className="relative w-full mb-8">
      {stats.thumbnails.banner && (
        <div className="w-full h-48 md:h-64 overflow-hidden rounded-t-lg">
          <img
            src={stats.thumbnails.banner}
            alt="Channel banner"
            className="w-full h-full object-cover"
          />
        </div>
      )}
      
      <div className="bg-white shadow-lg rounded-lg">
        <div className="p-6">
          <div className="flex flex-col md:flex-row gap-6 items-start">
            <img
              src={stats.thumbnails.medium}
              alt={stats.title}
              className="w-32 h-32 rounded-full ring-4 ring-white shadow-lg"
            />
            
            <div className="flex-1">
              <div className="flex items-start justify-between flex-wrap gap-4">
                <div>
                  <h1 className="text-3xl font-bold mb-2">{stats.title}</h1>
                  <a
                    href={`https://youtube.com/${stats.customUrl}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-red-600 hover:text-red-700 font-medium"
                  >
                    @{stats.customUrl}
                  </a>
                </div>
                
                {stats.socialLinks.length > 0 && (
                  <div className="flex gap-3">
                    {stats.socialLinks.map(({ platform, url }) => {
                      const Icon = socialIcons[platform];
                      return (
                        <a
                          key={platform}
                          href={url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-gray-600 hover:text-gray-900 transition-colors"
                        >
                          <Icon className="w-6 h-6" />
                        </a>
                      );
                    })}
                  </div>
                )}
              </div>
              
              <p className="mt-4 text-gray-600 whitespace-pre-line">
                {stats.description}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}