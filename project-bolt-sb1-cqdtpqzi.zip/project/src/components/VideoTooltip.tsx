import React from 'react';
import { VideoData } from '../types/youtube';
import { ThumbsUp, MessageSquare, Share2, ExternalLink, Eye } from 'lucide-react';

interface VideoTooltipProps {
  video: VideoData;
}

export function VideoTooltip({ video }: VideoTooltipProps) {
  return (
    <div className="bg-white p-4 rounded-lg shadow-lg border border-gray-200 max-w-sm">
      <a
        href={video.url}
        target="_blank"
        rel="noopener noreferrer"
        className="block group"
      >
        <div className="relative">
          <img
            src={video.thumbnail}
            alt={video.title}
            className="w-full h-auto rounded"
          />
          <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-10 transition-opacity flex items-center justify-center">
            <ExternalLink className="w-8 h-8 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>
        </div>
        
        <h3 className="font-medium text-sm mt-3 mb-2 line-clamp-2 group-hover:text-blue-600 transition-colors">
          {video.title}
        </h3>
      </a>

      <div className="grid grid-cols-2 gap-2 text-sm text-gray-600">
        <div className="flex items-center gap-1.5">
          <Eye className="w-4 h-4" />
          <span>{video.views.toLocaleString()}</span>
        </div>
        <div className="flex items-center gap-1.5">
          <ThumbsUp className="w-4 h-4" />
          <span>{video.likes.toLocaleString()}</span>
        </div>
        <div className="flex items-center gap-1.5">
          <MessageSquare className="w-4 h-4" />
          <span>{video.comments.toLocaleString()}</span>
        </div>
        <div className="flex items-center gap-1.5">
          <Share2 className="w-4 h-4" />
          <span>{video.shares.toLocaleString()}</span>
        </div>
      </div>
    </div>
  );
}