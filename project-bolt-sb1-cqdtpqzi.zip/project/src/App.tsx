import React, { useState } from 'react';
import { Download, Youtube } from 'lucide-react';
import { VideoTable } from './components/VideoTable';
import { StatsChart } from './components/StatsChart';
import { DateRangePicker } from './components/DateRangePicker';
import { ChannelSearch } from './components/ChannelSearch';
import { ErrorMessage } from './components/ErrorMessage';
import { VideoType, VideoData, ChannelStats } from './types/youtube';
import { exportToExcel } from './utils/export';
import { getChannelData } from './utils/youtube-api';

const videoTypes: VideoType[] = [
  'Video',
  'Short',
  'Live',
  'Playlist',
  'Post',
  'Podcast',
  'Promotion',
];

function App() {
  const [startDate, setStartDate] = useState('2024-01-01');
  const [endDate, setEndDate] = useState('2024-03-15');
  const [selectedTypes, setSelectedTypes] = useState<VideoType[]>(['Video', 'Short']);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [channelData, setChannelData] = useState<{
    stats: ChannelStats;
    videos: VideoData[];
  } | null>(null);

  const handleChannelSearch = async (channelUrl: string) => {
    setIsLoading(true);
    setError(null);
    try {
      const data = await getChannelData(channelUrl);
      setChannelData(data);
    } catch (error) {
      setError(error instanceof Error ? error.message : 'An error occurred while fetching channel data');
    } finally {
      setIsLoading(false);
    }
  };

  const filteredData = channelData?.videos.filter(video => {
    const videoDate = new Date(video.publishedAt);
    return videoDate >= new Date(startDate) && videoDate <= new Date(endDate);
  }) ?? [];

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Youtube className="w-8 h-8 text-red-600" />
              <h1 className="text-3xl font-bold text-gray-900">
                YouTube Channel Analyzer
              </h1>
            </div>
            {channelData && (
              <button
                onClick={() => exportToExcel(filteredData)}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
              >
                <Download className="w-4 h-4" />
                Export Data
              </button>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
        <ChannelSearch onSearch={handleChannelSearch} isLoading={isLoading} />

        {error && (
          <ErrorMessage message={error} onClose={() => setError(null)} />
        )}

        {channelData && (
          <div className="bg-white rounded-lg shadow p-6 mb-6">
            <div className="grid grid-cols-3 gap-6 mb-6">
              <div className="p-4 bg-blue-50 rounded-lg">
                <h3 className="text-lg font-semibold text-blue-900">Subscribers</h3>
                <p className="text-2xl font-bold text-blue-600">
                  {channelData.stats.subscriberCount.toLocaleString()}
                </p>
              </div>
              <div className="p-4 bg-green-50 rounded-lg">
                <h3 className="text-lg font-semibold text-green-900">Total Videos</h3>
                <p className="text-2xl font-bold text-green-600">
                  {channelData.stats.videoCount.toLocaleString()}
                </p>
              </div>
              <div className="p-4 bg-purple-50 rounded-lg">
                <h3 className="text-lg font-semibold text-purple-900">Total Views</h3>
                <p className="text-2xl font-bold text-purple-600">
                  {channelData.stats.viewCount.toLocaleString()}
                </p>
              </div>
            </div>

            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <DateRangePicker
                  startDate={startDate}
                  endDate={endDate}
                  onStartDateChange={setStartDate}
                  onEndDateChange={setEndDate}
                />
                <div className="flex gap-2 flex-wrap">
                  {videoTypes.map((type) => (
                    <label key={type} className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={selectedTypes.includes(type)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedTypes([...selectedTypes, type]);
                          } else {
                            setSelectedTypes(selectedTypes.filter(t => t !== type));
                          }
                        }}
                        className="rounded text-blue-600"
                      />
                      <span className="text-sm text-gray-700">{type}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <StatsChart data={filteredData} selectedTypes={selectedTypes} />
              </div>

              <VideoTable data={filteredData} />
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

export default App;